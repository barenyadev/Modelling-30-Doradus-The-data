#
# Import NumPy for array handling
#
import numpy as np
import os
#
# Import plotting libraries (start Python with ipython --matplotlib)
#
#from mpl_toolkits.mplot3d import axes3d
#from matplotlib import pyplot as plt
#
# Some natural constants
#
au  = 1.49598e13     # Astronomical Unit       [cm]
pc  = 3.08572e18     # Parsec                  [cm]
ms  = 1.98892e33     # Solar mass              [g]
ts  = 5.78e3         # Solar temperature       [K]
ls  = 3.8525e33      # Solar luminosity        [erg/s]
rs  = 6.96e10        # Solar radius            [cm]
#
# Monte Carlo parameters
#
nphot    = 1000000
#
# Grid parameters
#
nx       = 100
ny       = 100
nz       = 100
sizex    = 100*pc
sizey    = 100*pc
sizez    = 100*pc
#
# Model parameters
#
radius   = 60*pc
rho0     = 5.478e-26
#
# Star parameters
#
nstars = 10
mstar1 = 196 * ms
rstar1 = 34 * rs
tstar1 = 8.66*ts
pstar1 = np.array([6.975930, -41.962392, -26.277250724])

mstar2 = 151 * ms
rstar2 = 25.10 * rs
tstar2 = 8.33*ts
pstar2 = np.array([6.997703, -41.9741136, -26.252715])

mstar3 = 155 * ms
rstar3 = 25.39 * rs
tstar3 = 8.33*ts
pstar3 = np.array([6.9977692, -41.974066, -26.252790])

mstar4 = 108 * ms
rstar4 = 18.39 * rs
tstar4 = 8.33*ts
pstar4 = np.array([6.997622, -41.9740901, -26.25279017])

mstar5 = 116 * ms
rstar5 = 20.9 * rs
tstar5 = 8*ts
pstar5 = np.array([6.997630, -41.974135, -26.2527159])

mstar6 = 105 * ms
rstar6 = 16.24* rs
tstar6 = 8.66*ts
pstar6 = np.array([6.9978424, -41.97405399, -26.25279017])

mstar7 = 127 * ms
rstar7 = 17.29 * rs
tstar7 = 9*ts
pstar7 = np.array([6.99763776, -41.974181023, -26.25264164])

mstar8 = 96 * ms
rstar8 = 16.88 * rs
tstar8 = 8.16*ts
pstar8 = np.array([6.99747618, -41.9741150, -26.25279012])

mstar9 = 92 * ms
rstar9 = 39.56 * rs
tstar9 = 5.91*ts
pstar9 = np.array([6.99788768, -41.97432516, -26.2523445])

mstar10 = 142 * ms
rstar10 = 36.52 * rs
tstar10 = 7.02*ts
pstar10 = np.array([6.998130065, -41.974424108, -26.252121749])
# Make the coordinates
#
xi       = np.linspace(-sizex,sizex,nx+1)
yi       = np.linspace(-sizey,sizey,ny+1)
zi       = np.linspace(-sizez,sizez,nz+1)
xc       = 0.5 * ( xi[0:nx] + xi[1:nx+1] )
yc       = 0.5 * ( yi[0:ny] + yi[1:ny+1] )
zc       = 0.5 * ( zi[0:nz] + zi[1:nz+1] )
#
# Make the dust density model
#
qq       = np.meshgrid(xc,yc,zc,indexing='ij')
xx       = qq[0]
yy       = qq[1]
zz       = qq[2]
rr       = np.sqrt(xx**2+yy**2+zz**2)
rhod     = rho0 * np.exp(-(rr**2/radius**2)/2.0)
#
# Write the wavelength_micron.inp file
#
lam1     = 0.1e0
lam2     = 7.0e0
lam3     = 25.e0
lam4     = 2.0e2
n12      = 20
n23      = 100
n34      = 30
lam12    = np.logspace(np.log10(lam1),np.log10(lam2),n12,endpoint=False)
lam23    = np.logspace(np.log10(lam2),np.log10(lam3),n23,endpoint=False)
lam34    = np.logspace(np.log10(lam3),np.log10(lam4),n34,endpoint=True)
lam      = np.concatenate([lam12,lam23,lam34])
nlam     = lam.size
#
# Write the wavelength file
#
with open('wavelength_micron.inp','w+') as f:
    f.write('%d\n'%(nlam))
    for value in lam:
        f.write('%13.6e\n'%(value))
#
#
# Write the stars.inp file
#
with open('stars.inp','w+') as f:
    f.write('2\n')
    f.write('%d %d\n\n'%(nstars,nlam))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar1,mstar1,pstar1[0],pstar1[1],pstar1[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar2,mstar2,pstar2[0],pstar2[1],pstar2[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar3,mstar3,pstar3[0],pstar3[1],pstar3[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar4,mstar4,pstar4[0],pstar4[1],pstar4[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar5,mstar5,pstar5[0],pstar5[1],pstar5[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar6,mstar6,pstar6[0],pstar6[1],pstar6[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar7,mstar7,pstar7[0],pstar7[1],pstar7[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar8,mstar8,pstar8[0],pstar8[1],pstar8[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar9,mstar9,pstar9[0],pstar9[1],pstar9[2]))
    f.write('%13.6e %13.6e %13.6e %13.6e %13.6e\n\n'%(rstar10,mstar10,pstar10[0],pstar10[1],pstar10[2]))
    for value in lam:
        f.write('%13.6e\n'%(value))
    f.write('\n%13.6e\n'%(-tstar1))
    f.write('\n%13.6e\n'%(-tstar2))
    f.write('\n%13.6e\n'%(-tstar3))
    f.write('\n%13.6e\n'%(-tstar4))
    f.write('\n%13.6e\n'%(-tstar5))
    f.write('\n%13.6e\n'%(-tstar6))
    f.write('\n%13.6e\n'%(-tstar7))
    f.write('\n%13.6e\n'%(-tstar8))
    f.write('\n%13.6e\n'%(-tstar9))
    f.write('\n%13.6e\n'%(-tstar10))
#
# Write the grid file
#
with open('amr_grid.inp','w+') as f:
    f.write('1\n')                       # iformat
    f.write('0\n')                       # AMR grid style  (0=regular grid, no AMR)
    f.write('0\n')                       # Coordinate system
    f.write('0\n')                       # gridinfo
    f.write('1 1 1\n')                   # Include x,y,z coordinate
    f.write('%d %d %d\n'%(nx,ny,nz))     # Size of grid
    for value in xi:
        f.write('%13.6e\n'%(value))      # X coordinates (cell walls)
    for value in yi:
        f.write('%13.6e\n'%(value))      # Y coordinates (cell walls)
    for value in zi:
        f.write('%13.6e\n'%(value))      # Z coordinates (cell walls)
#
# Write the density file
#
with open('dust_density.inp','w+') as f:
    f.write('1\n')                       # Format number
    f.write('%d\n'%(nx*ny*nz))           # Nr of cells
    f.write('1\n')                       # Nr of dust species
    data = rhod.ravel(order='F')         # Create a 1-D view, fortran-style indexing
    data.tofile(f, sep='\n', format="%13.6e")
    f.write('\n')
#
# Dust opacity control file
#
with open('dustopac.inp','w+') as f:
    f.write('2               Format number of this file\n')
    f.write('1               Nr of dust species\n')
    f.write('============================================================================\n')
    f.write('1               Way in which this dust species is read\n')
    f.write('0               0=Thermal grain\n')
    f.write('LMCavgdust        Extension of name of dustkappa_***.inp file\n')
    f.write('----------------------------------------------------------------------------\n')
#
# Write the radmc3d.inp control file
#
with open('radmc3d.inp','w+') as f:
    f.write('nphot = %d\n'%(nphot))
    f.write('scattering_mode_max = 2\n')   # Put this to 1 for isotropic scattering
    f.write('iranfreqmode = 1\n')
